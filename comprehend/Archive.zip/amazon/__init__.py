# -*- coding: utf-8 -*-

"""
Python Amazon Simple Product Api
~~~~~~~
Amazon Product Advertising API Client library.
"""

__version__ = '2.2.11'
__author__ = 'Yoav Aviram'
